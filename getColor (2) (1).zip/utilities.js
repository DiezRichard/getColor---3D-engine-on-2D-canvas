//LOADER 2
function loadObject2(file){
let request = new XMLHttpRequest();
let mesh= [];
request.open("GET", file, false);
 
request.onreadystatechange = function()
{

if (request.readyState === 4)
{
if (request.status === 200 || request.status == 0)
{

let obj=request.responseText;
let str=String(obj);

 let arr= str.split(/\n/);
 let vectors=[];
 
 //VECTORS
for(let i=0;i<arr.length;i++)
{

//vectors
if (arr[i].match(/^v\s/))
{
//erase
 let p= arr[i].replace("v ","");
 let s=p.replace("v ","");
 //change "," with "."
s= p.replace(/\,/gm,".");
//split into 3 coords
let v= s.split(/\s/);
//fill in vector coords in numbers
let c={x:(+v[0]),y:(+v[1]),z:(+v[2])};

vectors.push(c);


}

}//VECTORS
 
 //TRIANGLES
 for(let i=0;i<arr.length;i++)
{
//triangles
if(arr[i].match(/^f/))
{
//clean
let clean= arr[i].replace("f ","");
//split
let split= clean.split(/\s/);

 // take the first value
let index1= +split[0].match(/\d+/m); 
let index2= +split[1].match(/\d+/m);
let index3= +split[2].match(/\d+/m);

let triangle=[];


triangle.push(vectors[index1-1],vectors[index2-1],vectors[index3-1]);

triangle.visible=true;

mesh.push(triangle);

}
}//TRIANGLES
}
}
}
request.send(null);

return mesh;
};// LOADER 2

//-----------------------//

//UTILITIES

function matrixTimesVector(v, matrix) {
let x1 = v.x * matrix[0][0] + v.y * matrix[1][0] + v.z * matrix[2][0];
let y1 = v.x * matrix[0][1] + v.y * matrix[1][1] + v.z * matrix[2][1];
let z1 = v.x * matrix[0][2] + v.y * matrix[1][2] + v.z * matrix[2][2];

let vec = { x: x1, y: y1, z: z1 };

return vec;
}

//-----------------------//

function cross(v1, v2) {
  return {
    x: v1.y * v2.z - v1.z * v2.y,
    y: v1.z * v2.x - v1.x * v2.z,
    z: v1.x * v2.y - v1.y * v2.x
  };
}
//-----------------------//

function vectorSub(v1,v2)
{
return {x:(v1.x-v2.x),y:(v1.y-v2.y),z:(v1.z-v2.z)};
}

//-----------------------//


function normV(v)
{
let len=(Math.sqrt((v.x*v.x+v.y*v.y+v.z*v.z)));
//len=Math.floor(len);
let newV={x:v.x/len,y:v.y/len,z:v.z/len};

return newV;
}


//-----------------------//

function dotP(v1,v2){
return v1.x*v2.x+v1.y*v2.y+v1.z*v2.z;

}

//-----------------------//

function meshByMatrix(mesh, matrix) {
  for (let tri of mesh) {
    if (tri.visible === false) continue;
    for (let v of tri) {
      let x = v.x, y = v.y, z = v.z;

      v.x = x * matrix[0][0] + y * matrix[0][1] + z * matrix[0][2] + matrix[0][3];
      v.y = x * matrix[1][0] + y * matrix[1][1] + z * matrix[1][2] + matrix[1][3];
      v.z = x * matrix[2][0] + y * matrix[2][1] + z * matrix[2][2] + matrix[2][3];
      v.w = x * matrix[3][0] + y * matrix[3][1] + z * matrix[3][2] + matrix[3][3];
    }
  }
 // return mesh;
}
//-----------------------//


//-----------------------//

function normalizeVector(vector) {
let length = vectorLength(vector);
return { x: vector.x / length, y: vector.y / length, z: vector.z / length };
}

//-----------------------//

function vectorLength(vector) {
return Math.sqrt(vector.x * vector.x + vector.y * vector.y + vector.z * vector.z);
}

//-----------------------//

function calculateTriangleNormal(triangle) {

 let tempVec1 = vectorFromVertices(triangle[0], triangle[1]);
 let tempVec2 = vectorFromVertices(triangle[0], triangle[2]);

let normal = {
x: tempVec1.y * tempVec2.z - tempVec1.z * tempVec2.y,
y: tempVec1.z * tempVec2.x - tempVec1.x * tempVec2.z,
z: tempVec1.x * tempVec2.y - tempVec1.y * tempVec2.x
};

return normal;
}

//-----------------------//

function vectorFromVertices(v1, v2) {
return { x: v2.x - v1.x, y: v2.y - v1.y, z: v2.z - v1.z };
}

//-----------------------//

function matrixMultiply(matrix1, matrix2){
  let result = [];
  for (let i = 0; i < matrix1.length; i++) {
    result[i] = [];
    for (let j = 0; j < matrix2[0].length; j++) {
      let sum = 0;
      for (let k = 0; k < matrix1[0].length; k++) {
        sum += matrix1[i][k] * matrix2[k][j];
      }
      result[i][j] = sum;
    }
  }
  return result;
}

//-----------------------//
let meshdist1 =0;
let meshdist2 =0;
function sortMeshesByDistance(meshes){
  return meshes.sort((mesh1, mesh2) => {
   meshdist1 = vectorDistance(camera.position, mesh1.position);
     meshdist2 = vectorDistance(camera.position, mesh2.position);

    return meshdist2- meshdist1;
  });
}

//-----------------------//

function mapRange(value, inMin, inMax, outMin, outMax) {
return ((value - inMin) * (outMax - outMin)) / (inMax - inMin) + outMin;
}

//-----------------------//
let sum = { x: 0, y: 0, z: 0 };
function calculateCentroid(triangle) {


for (let i = 0; i < triangle.length; i++) 
{
sum.x += triangle[i].x;
sum.y += triangle[i].y;
sum.z += triangle[i].z;
}

let numVertices = triangle.length;

let centroid=
{ 
x: sum.x / numVertices, 
y: sum.y / numVertices, 
z: sum.z / numVertices 
}

return centroid;
}

//-----------------------//

function sortTriByDist(mesh){

for (let i = 0; i < mesh.length; i++) 
{
let centroid = calculateCentroid(mesh[i]);

mesh[i].distance = vectorDistance(centroid, camera.position);
}

mesh.sort(function(a, b) 
{
return b.distance - a.distance;
});

}

//-----------------------//
let ab=0;
let tNumerator=0;
 let tDenominator=0;
 let tndtd =0;
function segmentInterPlane(planePoint, planeNormal, a, b) {
   ab = vectorSub(b, a);
   tNumerator = dotP(vectorSub(planePoint, a), planeNormal);
   tDenominator = dotP(ab, planeNormal);
  
   tndtd = tNumerator / tDenominator;
  
  return {
    x: a.x + ab.x * t,
    y: a.y + ab.y * t,
    z: a.z + ab.z * t
  };
}

//-----------------------//

function createRotationMatrix(axis, angle) {
let cos = Math.cos(angle);
let sin = Math.sin(angle);
let t = 1 - cos;

let matrix = [
[t * axis.x * axis.x + cos, t * axis.x * axis.y - sin * axis.z, t * axis.x * axis.z + sin * axis.y, 0],
[t * axis.x * axis.y + sin * axis.z, t * axis.y * axis.y + cos, t * axis.y * axis.z - sin * axis.x, 0],
[t * axis.x * axis.z - sin * axis.y, t * axis.y * axis.z + sin * axis.x, t * axis.z * axis.z + cos, 0],
[0, 0, 0, 1]
];

return matrix;
}

//-----------------------//

function perspectiveDivide(mesh) {
  for (let i = 0; i < mesh.length; i++) {
    for (let j = 0; j < 3; j++) {
      if (mesh[i][j].w !== 0) {
        mesh[i][j].x /= mesh[i][j].w;
        mesh[i][j].y /= mesh[i][j].w;
        mesh[i][j].z /= mesh[i][j].w;
      }
    }
  }
}

//-----------------------//

function vectorDistance(vector1, vector2) {
  return Math.sqrt(
    (vector2.x - vector1.x) ** 2 +
    (vector2.y - vector1.y) ** 2 +
    (vector2.z - vector1.z) ** 2
  );
}
//-----------------------//

function sortMeshesByY(meshes) {
return meshes.sort((mesh1, mesh2) => {
// Ascending order (from lower to higher y-axis value)
return mesh1.position.y - mesh2.position.y;
});
}

//-----------------------//

function updateCameraVectors() {
 // Crear matrices de rotación (en orden Z * Y * X)
 let rx = createRotationMatrix({ x: 1, y: 0, z: 0 }, -camera.rotation.x);
 let ry = createRotationMatrix({ x: 0, y: 1, z: 0 }, -camera.rotation.y);
 let rz = createRotationMatrix({ x: 0, y: 0, z: 1 }, -camera.rotation.z);
 
 // Composición total de rotación
 let rotationMatrix = matrixMultiply(rx, ry, rz); // Asegurate que tu matrixMultiply acepta múltiples matrices
 
 // Recalcular ejes
 camera.forward = matrixTimesVector({ x: 0, y: 0, z: -1, w: 1 }, rotationMatrix);
 camera.up = matrixTimesVector({ x: 0, y: 1, z: 0, w: 1 }, rotationMatrix);
 camera.right = matrixTimesVector({ x: 1, y: 0, z: 0, w: 1 }, rotationMatrix);
 
 // Si necesitás normalizar:
 camera.forward = normV(camera.forward);
camera.up = normV(camera.up);
camera.right = normV(camera.right);
}

//-----------------------//

function createProfiler(ctx) {
  let data = {};
  let fps = 0;
  let lastFrameTime = performance.now();
 let frameCount = 0;
  let fpsTimer = performance.now();
  
  return {
    start(label) {
      data[label] = data[label] || {};
      data[label].start = performance.now();
    },
    
    end(label) {
      if (data[label] && data[label].start !== undefined) {
        let duration = performance.now() - data[label].start;
        data[label].duration = duration.toFixed(1) + " ms";
        delete data[label].start; // limpiamos solo el start, para evitar errores
      }
    },
    
    beginFrame() {
      let now = performance.now();
      frameCount++;
      if (now - fpsTimer >= 500) {
        fps = Math.round((frameCount * 1000) / (now - fpsTimer));
        fpsTimer = now;
        frameCount = 0;
      }
    },
    
    draw(x = 5, y = 20, lineHeight = 18) {
      ctx.fillStyle = "white";
      ctx.font = "18px monospace";
      ctx.fillText("FPS: " + fps, x, y);
      y += lineHeight;
      
      for (let label in data) {
        if (data[label].duration) {
          ctx.fillText(`${label}: ${data[label].duration}`, x, y);
          y += lineHeight;
        }
      }
    },
    
    reset() {
      // opcional: si no quieres que se borre nada, puedes comentar esto
      // for (let key in data) delete data[key];
    }
  };
}

//-----------------------//