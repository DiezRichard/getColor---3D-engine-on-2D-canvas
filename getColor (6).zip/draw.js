function clipMeshByPlane(mesh) {
 let planes = viewFrustum
 
 for (let i = 0; i < mesh.length; i++) {
  let tri = mesh[i];
  if (!tri.visible) continue;
  
  let visible = true;
  for (let plane of planes) {
   // Usar plano pre-normalizado
   let outsideCount = 0;
   
   for (let vertex of tri) {
    // Distancia signada sin normalización
    let dist = plane.nx * vertex.x +
     plane.ny * vertex.y +
     plane.nz * vertex.z + plane.d;
    
    if (dist < 0) outsideCount++;
   }
   
   // Triángulo completamente fuera de un plano
   if (outsideCount === 3) {
    visible = false;
    break;
   }
  }
  
  tri.visible = visible;
 }
}

//-----------------------//


function clipBehindCamera(mesh) {
  for (let tri of mesh) {
    tri.visible = tri.some(v =>
      dotP(vectorSub(v, camera.position), camera.forward) > 1
    );
  }
}
//-----------------------//

function clipMeshByDistance(mesh){
 

//DISTANCE CHECK
for (let u = 0; u < mesh.length; u++)
{
let tri = mesh[u];

if (!tri.visible) continue;

let insideVertices = [];
let outsideVertices = [];
let cent= calculateCentroid(tri);

let dist=vectorDistance(cent, camera.position);
let far=5600;
let near=0;
if(dist<far && dist > near)
{
tri.visible=true;
}
else
{
tri.visible=false;
}
}

}//CLIP BY DISTANCE

function clipMeshByDistance(mesh) {
 let camPos = camera.position;
 let near2 = 50 * 50; // Distancias al cuadrado
 let far2 = 1200 * 1200;
 
 for (let tri of mesh) {
  if (!tri.visible) continue;
  
  let centroid = calculateCentroid(tri);
  let dx = centroid.x - camPos.x;
  let dy = centroid.y - camPos.y;
  let dz = centroid.z - camPos.z;
  let dist2 = dx * dx + dy * dy + dz * dz;
  
  tri.visible = (dist2 > near2 && dist2 < far2);
 }
}

//-----------------------//

function clipMeshByTriSize(mesh) {

let factor=1000;
let thresholdSmall = 0.01;// 25/factor; // Adjust as needed for small area
let thresholdLarge = 350;//15*factor;
// Adjust as needed for large area

for (let i = 0; i < mesh.length; i++) {
let tri = mesh[i];

if (!tri.visible) continue;


let line1 = vectorSub(tri[1], tri[0]);

let line2 = vectorSub(tri[2], tri[0]);

let normal = cross(line1, line2);

let triMag= vectorLength(normal);

let triArea= triMag*factor;
//console.log(triArea); 

if (triArea < thresholdSmall)// || triArea > thresholdLarge) 
{
tri.visible = false;
}
}
}//clipMeshByTriSize

//-----------------------//

function clipMeshByAngle(mesh) {
let normCameraForward = normV(camera.forward);

for (let tri of mesh) {
 
 if (!tri.visible) continue;


let triN = normV(calculateTriangleNormal(tri));
let dp = dotP(triN, normCameraForward);

// Solo mostrar triángulos cuya normal esté orientada hacia la cámara
tri.visible = dp >=-0.99;
}
}

//-----------------------//

function clipMeshByViewport(mesh, xMin, yMin, xMax, yMax) {
 return mesh.filter(tri => {
  return tri.some(v =>
   v.x >= xMin && v.x <= xMax &&
   v.y >= yMin && v.y <= yMax
  );
 });
}
//-----------------------//

function filterVisibleTri(mesh){
mesh.filter(triangle => triangle.visible !== false);

}

//-----------------------//

function multiplyMatrices(...matrices) {
return matrices.reduce((acc, m) => matrixMultiply(acc, m));
}

//-----------------------//

function toWorldView(mesh) {
let xMatrix = createRotationMatrix({ x: 1, y: 0, z: 0 }, mesh.rotation.x);
let yMatrix = createRotationMatrix({ x: 0, y: 1, z: 0 }, mesh.rotation.y);
let zMatrix = createRotationMatrix({ x: 0, y: 0, z: 1 }, mesh.rotation.z);

let tMatrix = [
[mesh.scale, 0, 0, mesh.position.x],
[0, mesh.scale, 0, mesh.position.y],
[0, 0, mesh.scale, mesh.position.z],
[0, 0, 0, 1],
];


 meshByMatrix(mesh, multiplyMatrices(tMatrix, zMatrix, yMatrix, xMatrix));
}

//-----------------------//

// Cachés separados
let lastCamPos = { x: NaN, y: NaN, z: NaN };
let lastCamRot = { x: NaN, y: NaN, z: NaN };

let cachedCamPosMatrix = null;
let cachedRotationMatrix = null;
let cachedViewMatrix = null;

function toCameraView(mesh) {
  const posChanged =
    camera.position.x !== lastCamPos.x ||
    camera.position.y !== lastCamPos.y ||
    camera.position.z !== lastCamPos.z;
  
  const rotChanged =
    camera.rotation.x !== lastCamRot.x ||
    camera.rotation.y !== lastCamRot.y ||
    camera.rotation.z !== lastCamRot.z;
  
  // --- Recalcular solo si cambió posición ---
  if (posChanged) {
    lastCamPos.x = camera.position.x;
    lastCamPos.y = camera.position.y;
    lastCamPos.z = camera.position.z;
    
    cachedCamPosMatrix = [
      [1, 0, 0, -camera.position.x],
      [0, 1, 0, -camera.position.y],
      [0, 0, 1, -camera.position.z],
      [0, 0, 0, 1]
    ];
  }
  
  // --- Recalcular solo si cambió rotación ---
  if (rotChanged) {
    lastCamRot.x = camera.rotation.x;
    lastCamRot.y = camera.rotation.y;
    lastCamRot.z = camera.rotation.z;
    
    const rx = createRotationMatrix({ x: 1, y: 0, z: 0 }, -camera.rotation.x);
    const ry = createRotationMatrix({ x: 0, y: 1, z: 0 }, -camera.rotation.y);
    const rz = createRotationMatrix({ x: 0, y: 0, z: 1 }, -camera.rotation.z);
    cachedRotationMatrix = matrixMultiply(rx, ry, rz);
    
    camera.forward = matrixTimesVector({ x: 0, y: 0, z: 1 }, cachedRotationMatrix);
    camera.up = matrixTimesVector({ x: 0, y: 1, z: 0 }, cachedRotationMatrix);
    camera.right = matrixTimesVector({ x: 1, y: 0, z: 0 }, cachedRotationMatrix);
  }
  
  // --- Recalcular matriz vista completa solo si cambió pos o rot ---
  if (posChanged || rotChanged) {
    cachedViewMatrix = matrixMultiply(cachedRotationMatrix, cachedCamPosMatrix);
    
    // Actualizar posición de la luz (depende de ambas)
    const rY = camera.rotation.y;
    light.position = {
      x: camera.position.x - 120 * Math.sin(rY),
      y: 80,
      z: camera.position.z + 120 * Math.cos(rY)
    };
  }
  
  meshByMatrix(mesh, cachedViewMatrix);
}


//-----------------------//

function updateThirdPersonCamera(target) {
  let distance = 80; 
  let height = 40;

  camera.position.x = target.x - distance * Math.sin(camera.rotation.y);
  camera.position.z = target.z - distance * Math.cos(camera.rotation.y);
  camera.position.y = target.y + height;
  

  let dx = target.x - camera.position.x;
  let dy = target.y - camera.position.y;
  let dz = target.z - camera.position.z;
  
  camera.rotation.y = Math.atan2(dx, dz); 
  camera.rotation.x = Math.atan2(dy, Math.hypot(dx, dz)); 
}

//-----------------------//

function toClipSpace(mesh) {
  meshByMatrix(mesh, [
    [canvas.width, 0, canvas.width / 3, 0],
    [0, canvas.height, canvas.height / 3, 0],
    [0, 0, 1, 1],
    [0, 0, 0, 0]
  ]);
}

//-----------------------//


function addColor(mesh) {
  for (let i = 0; i < mesh.length; i++) {
    mesh[i].color = getColor3(mesh[i], mesh.baseColor ?? defaultColor);
  }
}


//-----------------------//

function getColor3(tri, baseColor) {
  let v0 = tri[0], v1 = tri[1], v2 = tri[2];
  let dx1 = v1.x - v0.x, dy1 = v1.y - v0.y, dz1 = v1.z - v0.z;
  let dx2 = v2.x - v0.x, dy2 = v2.y - v0.y, dz2 = v2.z - v0.z;

  let nx = dy1 * dz2 - dz1 * dy2;
  let ny = dz1 * dx2 - dx1 * dz2;
  let nz = dx1 * dy2 - dy1 * dx2;

  let invLen = 1 / Math.sqrt(nx * nx + ny * ny + nz * nz);
  let dot = (nx * lightDir.x + ny * lightDir.y + nz * lightDir.z) * invLen;

  // Iluminación por pasos
  let steps = 10;
  let stepped = Math.round(Math.max(0, dot) * (steps - 1)) / (steps - 1);
  let intensity = 0.3 + 0.7 * stepped;

  // Obtener altura promedio del triángulo
  let avgY = (v0.y + v1.y + v2.y) / 3;

  // Colores por rango de Y
  let r = 0, g = 0, b = 0;
  if (avgY < -10) {
    r = 40; g = 60; b = 200;  // azul oscuro (agua)
  } else if (avgY < 0) {
    r = 50; g = 160; b = 60;  // verde pasto
  } else if (avgY < 10) {
    r = 180; g = 160; b = 60; // amarillento (arena)
  } else if (avgY < 20) {
    r = 200; g = 100; b = 50; // naranja-rocoso
  } else {
    r = 250; g = 250; b = 255; // nieve
  }

  // Aplicar iluminación
  r = (r * intensity) | 0;
  g = (g * intensity) | 0;
  b = (b * intensity) | 0;

  return `rgb(${r},${g},${b})`;
}





function drawMesh(m) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  let triangleCount = 0;
  ctx.lineWidth = 0.5;
  ctx.font = "14px monospace";


  let colorGroups = {};
  for (let i = 0; i < m.length; i++) {
    let tri = m[i];
    if (!tri.visible) continue;
    if (!colorGroups[tri.color]) colorGroups[tri.color] = [];
    colorGroups[tri.color].push(tri);
  }


  for (let color in colorGroups) {
    ctx.fillStyle = color;
    //ctx.strokeStyle = color;
    let group = colorGroups[color];
    for (let i = 0; i < group.length; i++) {
      let tri = group[i];
      let p0 = tri[0], p1 = tri[1], p2 = tri[2];

      ctx.beginPath();
      ctx.moveTo(p0.x, p0.y);
      ctx.lineTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.closePath();
      //ctx.stroke();
      ctx.fill();

      triangleCount++;
    }
  }

  ctx.fillStyle = "black";
  ctx.font = "18px monospace";
ctx.fillStyle = "white";
ctx.fillText("tri-count: " + triangleCount, 100, 20);
}




