let width = 300;
let height = 300;


let canvas = document.getElementById("myCanvas");


let ctx = canvas.getContext("2d");

let scale = window.devicePixelRatio || 0.5;



canvas.style.width = width + "px";
canvas.style.height = height + "px";

canvas.width = width * scale;
canvas.height = height * scale;

ctx.scale(scale, scale);

ctx.isSmoothEnable = false;

//-----------------------//

let camera = {
  position: { x: 0, y: 180, z: 0 },
  forward: { x: 0, y: 0, z: 1 },
  up: { x: 0, y: 1, z: 0 },
  right: { x: 1, y: 0, z: 0 },
  velocity: { x: 1, y: -0.1, z: 0 },
  rotation: { x: 0, y: 0, z: 0 },
  speed: 0.5
};

//-----------------------//

let cameraView="";

cameraView="top-down";
let forwardV=camera.forward;
let upV=camera.up;
let rightV=camera.right;

//-----------------------//

let rotationSpeed = 0.05;
let moveSpeed = camera.speed;

let radian = Math.PI / 180;
let fov=60;
let f= 1 / Math.tan((fov / 2)*(Math.PI / 180));
let a=height/width;
let zNear=1;
let zFar=1000;
let q=zFar/(zNear-zFar);

//-----------------------//

let leftPlane = {
normal: { x: -1, y: 0, z: 0 },
position: { x: 1, y: 0, z: 0 },
};

let rightPlane = {
normal: { x: 1, y: 0, z: 0},
position: { x: -1, y: 0, z: 0 },
};

let topPlane = {
normal: { x: 0, y: -1, z: 0 },
position: { x: 0, y: 1, z: 0 },
};

let bottomPlane = {
normal: { x: 0, y: 1, z: 0 },
position: { x: 0, y: -1, z: 0 },
};

let viewFrustum = 
[
leftPlane, 
rightPlane,
topPlane,
bottomPlane,

];
//-----------------------//

let pMatrix = [
 [f / a, 0, 0, 0],
 [0, f, 0, 0],
 [0, 0, (zFar + zNear) / (zNear - zFar), (2 * zFar * zNear) / (zNear - zFar)],
 [0, 0, -1, 0]
];

//-----------------------//

let meshes = [];

//-----------------------//

let gridSize = 50;
let cellSize = 2;
let tileScale =0.5;

let offset =width/20; 

let howTall=0;
//-----------------------//

gridLimit = 1000000000;

let frequency = 0.01;
let beef = 44; //tall

let random = Math.random() * 1000;

//-----------------------//


let light = loadObject2("obj/sphere.obj");
light.scale = 10;
light.position = { x: 0, y: camera.position.y, z: 0};
light.name = "light";
light.baseColor = { r: 255, g: 250, b: 0 };
light.rotation = { x: 0, y: 0, z: 0 };

let lightDir = normV({ x: -1, y: -1, z: -1 });

//-----------------------//

let lastTime = performance.now();
let frameCount = 0;
let fps = 0;
let fpsTimer = performance.now();

//-----------------------//

let perm = [];
for (let i = 0; i < 256; i++) perm[i] = i;
perm.sort(() => Math.random() - 0.5);
perm = perm.concat(perm);

//-----------------------//

let tempVec1={};
let tempVec2={};
let tempNormal=0;
let tempLength =0;
let tempDot1 = 0;
let tempAngle = 0;
let cellPool = {};
let defaultColor = { r: 50, g: 250, b: 50 };
