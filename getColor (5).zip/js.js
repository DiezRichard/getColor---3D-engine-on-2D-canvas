let grid = createGrid(0,0);
let alltris = [];
let allmeshes = [];

let tickLetters = ['a','b1','b2','c'];
let tickIndex = 0;
let tick = tickLetters[tickIndex];

let profiler = createProfiler(ctx);


//-----------------------//
/*
function main() {
 profiler.beginFrame();
 
 
 if (cameraView == "top-down") {
camera.rotation.x = Math.PI / 180 * 90;
 }
 
 tickIndex = (tickIndex + 1) % tickLetters.length;
 tick = tickLetters[tickIndex];
 
 // FPS
 let now = performance.now();
 frameCount++;
 
 if (now - fpsTimer >= 500) {
fps = Math.round((frameCount * 1000) / (now - fpsTimer));
fpsTimer = now;
frameCount = 0;
 }
 
let camPosX = (camera.position.x / (cellSize * tileScale)) | 0;
let camPosZ = (camera.position.z / (cellSize * tileScale)) | 0;
 
 if (tick == "a" || (tick=="a"&&dragging)) {
grid = createGrid(camPosX, camPosZ);

alltris.length = 0;
allmeshes.length = 0;


for (let i = 0; i < meshes.length; i++) {
// allmeshes[i] = meshes[i];
}

for (let i = 0; i < grid.length; i++) {
 //allmeshes[meshes.length + i] = grid[i];
}

//sortMeshesByDistance(allmeshes);
 }
 
 
 if (tick == "b") {

for (let meshIndex = 0; meshIndex < grid.length; meshIndex++) {
 let mesh = grid[meshIndex];
 
 toWorldView(mesh);
 
 if (cameraView == "fp" ) {
applyGravity(camera.position.x, camera.position.z, mesh);
 }
 
 //sortTriByDist(mesh);
 addColor(mesh);
 
 clipBehindCamera(mesh);
 filterVisibleTri(mesh);
 
//clipMeshByDistance(mesh);
//clipMeshByAngle(mesh);
 
 toCameraView(mesh);
 
 meshByMatrix(mesh, pMatrix);
 
 perspectiveDivide(mesh);
 
//clipMeshByTriSize(mesh);
//clipMeshByPlane(mesh);
//filterVisibleTri(mesh);
 
 toClipSpace(mesh);
 
 let baseIndex = alltris.length;
 for (let i = 0; i < mesh.length; i++) {
alltris[baseIndex + i] = mesh[i];
 }
}
 }
 
 if (tick == "c") {
  moveCameraForward();

drawMesh(alltris);
 }
 
 if (tick == "d") {
for (let i = 0; i < meshes.length; i++) {
 let mesh = meshes[i];
 if (mesh.falling) {
for (let j = 0; j < grid.length; j++) {
 let cell = grid[j];
 let worldCell = toWorldView(cell);
 applyGravityToObject(mesh, worldCell);
}
 }
}
 }
 
 updateCamera();
 
 profiler.draw();
 profiler.reset();
 
 requestAnimationFrame(main);
}
*/
function main() {
 profiler.beginFrame();
 
 if (cameraView == "top-down") {
  camera.rotation.x = Math.PI / 180 * 90;
 }
 
 tickIndex = (tickIndex + 1) % tickLetters.length;
 tick = tickLetters[tickIndex];
 
 // FPS
 let now = performance.now();
 frameCount++;
 if (now - fpsTimer >= 500) {
  fps = Math.round((frameCount * 1000) / (now - fpsTimer));
  fpsTimer = now;
  frameCount = 0;
 }
 
 let camPosX = (camera.position.x / (cellSize * tileScale)) | 0;
 let camPosZ = (camera.position.z / (cellSize * tileScale)) | 0;
 
 
 if (tick === "a" || (tick === "a" && dragging)) {
  //profiler.start()
  grid = createGrid(camPosX, camPosZ);
  alltris.length = 0;
  allmeshes.length = 0;
  //profiler.end()
 }
 
 
 let half = (grid.length / 2) | 0;
 
 
 if (tick === "b1") {
 // profiler.start()
  for (let meshIndex = 0; meshIndex < half; meshIndex++) {
   let mesh = grid[meshIndex];
   
   toWorldView(mesh);
   
   if (cameraView === "fp") {
    applyGravity(camera.position.x, camera.position.z, mesh);
   }
   
   addColor(mesh);
   toCameraView(mesh);
   clipBehindCamera(mesh);
   filterVisibleTri(mesh);
   meshByMatrix(mesh, pMatrix);
   perspectiveDivide(mesh);
   toClipSpace(mesh);
   
   let baseIndex = alltris.length;
   for (let i = 0; i < mesh.length; i++) {
    alltris[baseIndex + i] = mesh[i];
   }
  }
 // profiler.end()
 }
 
 
 if (tick === "b2") {
  //profiler.start()
  for (let meshIndex = half; meshIndex < grid.length; meshIndex++) {
   let mesh = grid[meshIndex];
   
   toWorldView(mesh);
   
   if (cameraView === "fp") {
    applyGravity(camera.position.x, camera.position.z, mesh);
   }
   
   addColor(mesh);
   toCameraView(mesh);
   clipBehindCamera(mesh);
   filterVisibleTri(mesh);
   meshByMatrix(mesh, pMatrix);
   perspectiveDivide(mesh);
   toClipSpace(mesh);
   
   let baseIndex = alltris.length;
   for (let i = 0; i < mesh.length; i++) {
    alltris[baseIndex + i] = mesh[i];
   }
  }
 // profiler.end()
 }
 
 
 if (tick === "c") {
  //profiler.start()
  moveCameraForward();
  drawMesh(alltris);
  //profiler.end()
 }
 
 
 /*
 if (tick === "c") {
  for (let i = 0; i < meshes.length; i++) {
   let mesh = meshes[i];
   if (mesh.falling) {
    for (let j = 0; j < grid.length; j++) {
     let cell = grid[j];
     let worldCell = toWorldView(cell);
     applyGravityToObject(mesh, worldCell);
    }
   }
  }
 }
 */
 updateCamera();
 profiler.draw();
profiler.reset();
 
 requestAnimationFrame(main);
}




window.onload=requestAnimationFrame(main);




