
// Definición de caras visibles
let faces = {
top: [// y+
[2, 6, 3], [3, 6, 7]
],
bottom: [ // y−
[0, 1, 4], [1, 5, 4]
],
left: [ // x−
[0, 2, 1], [1, 2, 3]
],
right: [// x+
[4, 5, 6], [5, 7, 6]
],
front: [// z+
[1, 3, 5], [5, 3, 7]
],
back: [ // z−
[0, 4, 2], [2, 4, 6]
]
};

// Vértices del cubo
let cubeVertices = [
{ x: 0, y: 0, z: 0 }, // 0
{ x: 0, y: 0, z: 1 }, // 1
{ x: 0, y: 1, z: 0 }, // 2
{ x: 0, y: 1, z: 1 }, // 3
{ x: 1, y: 0, z: 0 }, // 4
{ x: 1, y: 0, z: 1 }, // 5
{ x: 1, y: 1, z: 0 }, // 6
{ x: 1, y: 1, z: 1 }// 7
];

// Colores por altura
const heightColors = {
0: { r: 68, g: 68, b: 68 }, // #444444
1: { r: 102, g: 119, b: 68 }, // #667744
2: { r: 136, g: 170, b: 85 }, // #88aa55
3: { r: 204, g: 221, b: 136 } // #ccdd88
};

//-----------------------//


function getHeight(x, z) {
  let noiseVal = perlin(x * 0.1, z * 0.1); // Escala el input para control de frecuencia
  let normalized = (noiseVal + 1) / 2; // Rango [0,1]
  return Math.floor(normalized * 3); // Alturas: 0, 1 o 2
}

//-----------------------//

// Verifica si hay cubo en x, y, z
function isCubeAt(x, y, z, voxelsSet) {
return voxelsSet.has(`${x},${y},${z}`);
}

//-----------------------//

// Función principal
function createVoxelGrid(camPosX, camPosZ) {
let cells = [];
let voxelsSet = new Set();

// 1. Construir el set de =cubos
for (let row = 0; row < gridSize; row++) {
for (let col = 0; col < gridSize; col++) {
let baseX = col + camPosX;
let baseZ = row + camPosZ;

for (let i = 0; i < cellSize; i++) {
for (let u = 0; u < cellSize; u++) {
let worldX = baseX * cellSize + u;
let worldZ = baseZ * cellSize + i;
let height = getHeight(worldX, worldZ);

for (let y = 0; y <= height; y++) {
voxelsSet.add(`${worldX},${y},${worldZ}`);
}
}
}
}
}

// 2. Construir las celdas visibles
for (let row = 0; row < gridSize; row++) {
for (let col = 0; col < gridSize; col++) {
let cell = [];
cell.scale = tileScale;
cell.rotation = { x: 0, y: 0, z: 0 };
cell.name = "cell";

let baseX = col + camPosX;
let baseZ = row + camPosZ;

cell.position = {
x: baseX * cellSize * tileScale - offset,
y: 0,
z: baseZ * cellSize * tileScale - offset
};

for (let i = 0; i < cellSize; i++) {
for (let u = 0; u < cellSize; u++) {
let worldX = baseX * cellSize + u;
let worldZ = baseZ * cellSize + i;
let height = getHeight(worldX, worldZ);

for (let y = 0; y <= height; y++) {
let color = heightColors[y];

// Solo dibuja la cara superior si no está tapada por un cubo arriba
if (!isCubeAt(worldX, y + 1, worldZ, voxelsSet)) {
for (let tri of faces.top) {
let mesh = tri.map(idx => {
let v = cubeVertices[idx];
return {
x: v.x + u,
y: v.y + y,
z: v.z + i
};
});
cell.baseColor = color;
cell.push(mesh);
}
}
}
}
}

cells.push(cell);
}
}

return cells;
}