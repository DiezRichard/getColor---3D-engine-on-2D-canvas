function clipMeshByPlane(mesh) {
 let planes = viewFrustum
 
 for (let i = 0; i < mesh.length; i++) {
let tri = mesh[i];
if (!tri.visible) continue;

let visible = true;
for (let plane of planes) {
 // Usar plano pre-normalizado
 let outsideCount = 0;
 
 for (let vertex of tri) {
// Distancia signada sin normalización
let dist = plane.nx * vertex.x +
 plane.ny * vertex.y +
 plane.nz * vertex.z + plane.d;

if (dist < 0) outsideCount++;
 }
 
 // Triángulo completamente fuera de un plano
 if (outsideCount === 3) {
visible = false;
break;
 }
}

tri.visible = visible;
 }
}

//-----------------------//


function clipBehindCamera(mesh) {
for (let tri of mesh) {
tri.visible = tri.some(v =>
dotP(vectorSub(v, camera.position), camera.forward) > 1
);
}
}
//-----------------------//

function clipMeshByDistance(mesh){
 

//DISTANCE CHECK
for (let u = 0; u < mesh.length; u++)
{
let tri = mesh[u];

if (!tri.visible) continue;

let insideVertices = [];
let outsideVertices = [];
let cent= calculateCentroid(tri);

let dist=vectorDistance(cent, camera.position);
let far=5600;
let near=0;
if(dist<far && dist > near)
{
tri.visible=true;
}
else
{
tri.visible=false;
}
}

}//CLIP BY DISTANCE

function clipMeshByDistance(mesh) {
let camPos = camera.position;
let near2 = 0.1;
let far2 = 100000;

for (let tri of mesh) {
if (!tri.visible) continue;

let minDist2 = Infinity;
for (let i = 0; i < 3; i++) {
let v = tri[i];
let dx = v.x - camPos.x;
let dy = v.y - camPos.y;
let dz = v.z - camPos.z;
let dist2 = dx * dx + dy * dy + dz * dz;
if (dist2 < minDist2) minDist2 = dist2;
}

tri.visible = (minDist2 > near2 && minDist2 < far2);
}
}

//-----------------------//

function clipMeshByTriSize(mesh) {

let factor=1000;
let thresholdSmall = 0.01;// 25/factor; // Adjust as needed for small area
let thresholdLarge = 350;//15*factor;
// Adjust as needed for large area

for (let i = 0; i < mesh.length; i++) {
let tri = mesh[i];

if (!tri.visible) continue;


let line1 = vectorSub(tri[1], tri[0]);

let line2 = vectorSub(tri[2], tri[0]);

let normal = cross(line1, line2);

let triMag= vectorLength(normal);

let triArea= triMag*factor;
//console.log(triArea); 

if (triArea < thresholdSmall)// || triArea > thresholdLarge) 
{
tri.visible = false;
}
}
}//clipMeshByTriSize

//-----------------------//

function clipMeshByAngle(mesh) {
let normCameraForward = normV(camera.forward);

for (let tri of mesh) {
 
 if (!tri.visible) continue;


let triN = normV(calculateTriangleNormal(tri));
let dp = dotP(triN, normCameraForward);

// Solo mostrar triángulos cuya normal esté orientada hacia la cámara
tri.visible = dp >=0;
}
}

//-----------------------//

function clipMeshByViewport(mesh, xMin, yMin, xMax, yMax) {
 return mesh.filter(tri => {
return tri.some(v =>
 v.x >= xMin && v.x <= xMax &&
 v.y >= yMin && v.y <= yMax
);
 });
}
//-----------------------//

function filterVisibleTri(mesh){
mesh.filter(triangle => triangle.visible !== false);

}

//-----------------------//

function multiplyMatrices(...matrices) {
return matrices.reduce((acc, m) => matrixMultiply(acc, m));
}

//-----------------------//

/*
function toWorldView(mesh) {
let xMatrix = createRotationMatrix({ x: 1, y: 0, z: 0 }, mesh.rotation.x);
let yMatrix = createRotationMatrix({ x: 0, y: 1, z: 0 }, mesh.rotation.y);
let zMatrix = createRotationMatrix({ x: 0, y: 0, z: 1 }, mesh.rotation.z);

let tMatrix = [
[mesh.scale, 0, 0, mesh.position.x],
[0, mesh.scale, 0, mesh.position.y],
[0, 0, mesh.scale, mesh.position.z],
[0, 0, 0, 1],
];


 meshByMatrix(mesh, multiplyMatrices(tMatrix, zMatrix, yMatrix, xMatrix));
}
*/

function toWorldView(meta) {
// Crea matrices de rotación
let xMatrix = createRotationMatrix({ x: 1, y: 0, z: 0 }, meta.rotation.x);
let yMatrix = createRotationMatrix({ x: 0, y: 1, z: 0 }, meta.rotation.y);
let zMatrix = createRotationMatrix({ x: 0, y: 0, z: 1 }, meta.rotation.z);

// Matriz de transformación para escalado y translación
let tMatrix = [
[meta.scale, 0, 0, meta.position.x],
[0, meta.scale, 0, 0], // Generalmente 0 en Y
[0, 0, meta.scale, meta.position.z],
[0, 0, 0, 1],
];

// Combina matrices
let transformationMatrix = multiplyMatrices(tMatrix, zMatrix, yMatrix, xMatrix);

// Procesa el mesh usando la matriz de transformación
meshByMatrix(meta, transformationMatrix, meta.baseVertex, meta.vertexCount, meta.baseIndex, meta.indexCount);
}


//-----------------------//

// Cachés separados
let lastCamPos = { x: NaN, y: NaN, z: NaN };
let lastCamRot = { x: NaN, y: NaN, z: NaN };

let cachedCamPosMatrix = null;
let cachedRotationMatrix = null;
let cachedViewMatrix = null;
/*
function toCameraView(mesh) {
let posChanged =
camera.position.x !== lastCamPos.x ||
camera.position.y !== lastCamPos.y ||
camera.position.z !== lastCamPos.z;

let rotChanged =
camera.rotation.x !== lastCamRot.x ||
camera.rotation.y !== lastCamRot.y ||
camera.rotation.z !== lastCamRot.z;

// --- Recalcular solo si cambió posición ---
if (posChanged) {
lastCamPos.x = camera.position.x;
lastCamPos.y = camera.position.y;
lastCamPos.z = camera.position.z;

cachedCamPosMatrix = [
[1, 0, 0, -camera.position.x],
[0, 1, 0, -camera.position.y],
[0, 0, 1, -camera.position.z],
[0, 0, 0, 1]
];
}

// --- Recalcular solo si cambió rotación ---
if (rotChanged) {
lastCamRot.x = camera.rotation.x;
lastCamRot.y = camera.rotation.y;
lastCamRot.z = camera.rotation.z;

let rx = createRotationMatrix({ x: 1, y: 0, z: 0 }, -camera.rotation.x);
let ry = createRotationMatrix({ x: 0, y: 1, z: 0 }, -camera.rotation.y);
let rz = createRotationMatrix({ x: 0, y: 0, z: 1 }, -camera.rotation.z);
cachedRotationMatrix = matrixMultiply(rx, ry, rz);

camera.forward = matrixTimesVector({ x: 0, y: 0, z: 1 }, cachedRotationMatrix);
camera.up = matrixTimesVector({ x: 0, y: 1, z: 0 }, cachedRotationMatrix);
camera.right = matrixTimesVector({ x: 1, y: 0, z: 0 }, cachedRotationMatrix);
}

// --- Recalcular matriz vista completa solo si cambió pos o rot ---
if (posChanged || rotChanged) {
cachedViewMatrix = matrixMultiply(cachedRotationMatrix, cachedCamPosMatrix);

// Actualizar posición de la luz (depende de ambas)
let rY = camera.rotation.y;
light.position = {
x: camera.position.x - 120 * Math.sin(rY),
y: 80,
z: camera.position.z + 120 * Math.cos(rY)
};
}

meshByMatrix(mesh, cachedViewMatrix);
}
*/

function toCameraView(meta) {
let posChanged =
camera.position.x !== lastCamPos.x ||
camera.position.y !== lastCamPos.y ||
camera.position.z !== lastCamPos.z;

let rotChanged =
camera.rotation.x !== lastCamRot.x ||
camera.rotation.y !== lastCamRot.y ||
camera.rotation.z !== lastCamRot.z;

// --- Recalcular solo si cambió posición ---
if (posChanged) {
lastCamPos.x = camera.position.x;
lastCamPos.y = camera.position.y;
lastCamPos.z = camera.position.z;

cachedCamPosMatrix = [
[1, 0, 0, -camera.position.x],
[0, 1, 0, -camera.position.y],
[0, 0, 1, -camera.position.z],
[0, 0, 0, 1]
];
}

// --- Recalcular solo si cambió rotación ---
if (rotChanged) {
lastCamRot.x = camera.rotation.x;
lastCamRot.y = camera.rotation.y;
lastCamRot.z = camera.rotation.z;

let rx = createRotationMatrix({ x: 1, y: 0, z: 0 }, -camera.rotation.x);
let ry = createRotationMatrix({ x: 0, y: 1, z: 0 }, -camera.rotation.y);
let rz = createRotationMatrix({ x: 0, y: 0, z: 1 }, -camera.rotation.z);
cachedRotationMatrix = matrixMultiply(rx, ry, rz);

camera.forward = matrixTimesVector({ x: 0, y: 0, z: 1 }, cachedRotationMatrix);
camera.up = matrixTimesVector({ x: 0, y: 1, z: 0 }, cachedRotationMatrix);
camera.right = matrixTimesVector({ x: 1, y: 0, z: 0 }, cachedRotationMatrix);
}

// --- Recalcular matriz vista completa solo si cambió pos o rot ---
if (posChanged || rotChanged) {
cachedViewMatrix = matrixMultiply(cachedRotationMatrix, cachedCamPosMatrix);

// Actualizar posición de la luz (depende de ambas)
let rY = camera.rotation.y;
light.position = {
x: camera.position.x - 120 * Math.sin(rY),
y: 80,
z: camera.position.z + 120 * Math.cos(rY)
};
}

// Aplicar la matriz de vista al mesh usando el índice base
meshByMatrix(meta, cachedViewMatrix);
}



//-----------------------//

function updateThirdPersonCamera(target) {
let distance = 80; 
let height = 40;

camera.position.x = target.x - distance * Math.sin(camera.rotation.y);
camera.position.z = target.z - distance * Math.cos(camera.rotation.y);
camera.position.y = target.y + height;


let dx = target.x - camera.position.x;
let dy = target.y - camera.position.y;
let dz = target.z - camera.position.z;

camera.rotation.y = Math.atan2(dx, dz); 
camera.rotation.x = Math.atan2(dy, Math.hypot(dx, dz)); 
}

//-----------------------//

function toClipSpace(meta) {
meshByMatrix(meta, [
[canvas.width, 0, canvas.width / 3, 0],
[0, canvas.height, canvas.height / 3, 0],
[0, 0, 1, 1],
[0, 0, 0, 0]
]);
}

//-----------------------//


// Color de prueba global (puedes cambiarlo)
const testColor = [120, 200, 150]; // RGB valores 0-255

function subV(a, b) {
return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
}

function crossV(a, b) {
return {
x: a.y * b.z - a.z * b.y,
y: a.z * b.x - a.x * b.z,
z: a.x * b.y - a.y * b.x
};
}

function dotV(a, b) {
return a.x * b.x + a.y * b.y + a.z * b.z;
}

function normV(v) {
let len = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
return { x: v.x / len, y: v.y / len, z: v.z / len };
}



let step =1;


function addColor(meta) {
 //let step = meta.stepping || 1;
for (let i = 0; i < meta.indexCount; i += 3 * step) {
let vi0 = indexBuffer[meta.baseIndex + i] * 3;
let vi1 = indexBuffer[meta.baseIndex + i + step] * 3;
let vi2 = indexBuffer[meta.baseIndex + i + 2 * step] * 3;

let y0 = vertexBuffer[vi0 + 1];
let y1 = vertexBuffer[vi1 + 1];
let y2 = vertexBuffer[vi2 + 1];


// Calcular normal
let edge1 = subV(
{ x: vertexBuffer[vi1], y: vertexBuffer[vi1 + 1], z: vertexBuffer[vi1 + 2] },
{ x: vertexBuffer[vi0], y: vertexBuffer[vi0 + 1], z: vertexBuffer[vi0 + 2] }
);
let edge2 = subV(
{ x: vertexBuffer[vi2], y: vertexBuffer[vi2 + 1], z: vertexBuffer[vi2 + 2] },
{ x: vertexBuffer[vi0], y: vertexBuffer[vi0 + 1], z: vertexBuffer[vi0 + 2] }
);
let normal = normV(crossV(edge1, edge2));

let dot = Math.max(0, dotV(normal, lightDir));
let stepped = Math.round(dot * (shadingSteps - 1)) / (shadingSteps - 1);
let intensity = 0.4 + 1 * stepped;

//let intensity = 1;

let avgY = (y0 + y1 + y2) / 3;

let r = 0, g = 0, b = 0;
if (avgY < -10) {
r = 40; g = 60; b = 200;
} else if (avgY < 0) {
r = 50; g = 160; b = 60;
} else if (avgY < 10) {
r = 180; g = 160; b = 60;
} else if (avgY < 20) {
r = 200; g = 100; b = 50;
} else {
r = 250; g = 250; b = 255;
}


r *= intensity;
g *= intensity;
b *= intensity;



r = Math.min(255, Math.max(0, Math.round(r)));
g = Math.min(255, Math.max(0, Math.round(g)));
b = Math.min(255, Math.max(0, Math.round(b)));

let triIndex = (meta.baseIndex / 3) + (i / (3 * step));
colorBuffer[triIndex * 3] = r;
colorBuffer[triIndex * 3 + 1] = g;
colorBuffer[triIndex * 3 + 2] = b;
}
}



offctx.lineWidth = 0.5;

offctx.font = "14px monospace";

function drawMesh() {

offctx.clearRect(0, 0, offctx.canvas.width, offctx.canvas.height);

let triangleCount = indexOffset / 3;


let groups = new Map();

for (let i = 0; i < triangleCount; i++) {
let r = colorBuffer[i * 3];
let g = colorBuffer[i * 3 + 1];
let b = colorBuffer[i * 3 + 2];

// Crear clave como entero 24 bits: 0xRRGGBB
let key = (r << 16) | (g << 8) | b;

if (!groups.has(key)) {
groups.set(key, []);
}
groups.get(key).push(i);
}

for (let [key, tris] of groups) {

let r = (key >> 16) & 0xFF;
let g = (key >> 8) & 0xFF;
let b = key & 0xFF;

offctx.fillStyle = `rgb(${r},${g},${b})`;

let batchSize = 60;
for (let start = 0; start < tris.length; start += batchSize) {
let end = Math.min(start + batchSize, tris.length);
offctx.beginPath();
for (let i = start; i < end; i++) {
let triIndex = tris[i];

let i0 = indexBuffer[triIndex * 3];
let i1 = indexBuffer[triIndex * 3 + 1];
let i2 = indexBuffer[triIndex * 3 + 2];

let p0x = vertexBuffer[i0 * 3], p0y = vertexBuffer[i0 * 3 + 1];
let p1x = vertexBuffer[i1 * 3], p1y = vertexBuffer[i1 * 3 + 1];
let p2x = vertexBuffer[i2 * 3], p2y = vertexBuffer[i2 * 3 + 1];

offctx.moveTo(p0x, p0y);
offctx.lineTo(p1x, p1y);
offctx.lineTo(p2x, p2y);
offctx.closePath();
}
offctx.fill();
}
}

offctx.fillStyle = "white";
offctx.fillText("tri-count: " + triangleCount, 100, 20);
}

