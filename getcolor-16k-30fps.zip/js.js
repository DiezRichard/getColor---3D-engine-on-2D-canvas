let grid = createGrid(0,0);
sortMeshesByDistance(grid);
let alltris = [];
let allmeshes = [];

let profiler = createProfiler(ctx);


//-----------------------//
let saveW=false;

function main() {
 profiler.beginFrame();
 
 
 if (cameraView == "top-down") {
camera.rotation.x = Math.PI / 180 * 90;
 }
 
 
 // FPS
 let now = performance.now();
 frameCount++;
 if (now - fpsTimer >= 500) {
fps = Math.round((frameCount * 1000) / (now - fpsTimer));
fpsTimer = now;
frameCount = 0;
 }
 
 let camPosX = (camera.position.x / (cellSize * tileScale)) | 0;
 let camPosZ = (camera.position.z / (cellSize * tileScale)) | 0;
 
 
//profiler.start()
grid = createGrid(camPosX, camPosZ);
alltris.length = 0;
//allmeshes.length = 0;

//grid = sortMeshesByDistance(grid);
//profiler.end()

//profiler.start()
 for (let i= 0; i < grid.length; i++) {
  let meta = grid[i];
  
  toWorldView(meta);
  addColor(meta);
  
  toCameraView(meta);
  
  saveW = true;
  meshByMatrix(meta, pMatrix);
  
  perspectiveDivide(meta);
  toClipSpace(meta);
  
  saveW = false;
 }
//profiler.end()

ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
 
 moveCameraForward();
 
 //profiler.start()
 drawMesh();
 //profiler.end()
 drawCanvas();



 /*
 if (tick === "b1") {
 // profiler.start()
for (let meshIndex = 0; meshIndex < half; meshIndex++) {
 let mesh = grid[meshIndex];
 
 toWorldView(mesh);
 
 if (cameraView === "fp") {
applyGravity(camera.position.x, camera.position.z, mesh);
 }
 
if (isSortTriDist) { 
sortTriByDist(mesh);
}

addColor(mesh);

if (isClipBehindCam) {
clipBehindCamera(mesh);
}
if(isClipByDist){
clipMeshByDistance(mesh);
}
if (isClipByAngle) {
clipMeshByAngle(mesh);
}

toCameraView(mesh);

meshByMatrix(mesh, pMatrix);
perspectiveDivide(mesh);

if (isClipByTriSize) {
clipMeshByTriSize(mesh);
}
if (isClipByPlane) {
clipMeshByPlane(mesh);
}
filterVisibleTri(mesh);

toClipSpace(mesh);
 
 let baseIndex = alltris.length;
 for (let i = 0; i < mesh.length; i++) {
alltris[baseIndex + i] = mesh[i];
 }
}
 // profiler.end()
 }
 */
 
 /*
 if (tick === "b2") {
//profiler.start()
for (let meshIndex = half; meshIndex < grid.length; meshIndex++) {
 let mesh = grid[meshIndex];
 
 toWorldView(mesh);
 
 if (cameraView === "fp") {
applyGravity(camera.position.x, camera.position.z, mesh);
 }
 
if (isSortTriDist) {
 sortTriByDist(mesh);
}

addColor(mesh);

if (isClipBehindCam) {
 clipBehindCamera(mesh);
}
if (isClipByDist) {
 clipMeshByDistance(mesh);
}
if (isClipByAngle) {
 clipMeshByAngle(mesh);
}

toCameraView(mesh);

meshByMatrix(mesh, pMatrix);
perspectiveDivide(mesh);

if (isClipByTriSize) {
 clipMeshByTriSize(mesh);
}
if (isClipByPlane) {
 clipMeshByPlane(mesh);
}
filterVisibleTri(mesh);

toClipSpace(mesh);
 
 let baseIndex = alltris.length;
 for (let i = 0; i < mesh.length; i++) {
alltris[baseIndex + i] = mesh[i];
 }
}
 // profiler.end()
 }
 */
 /*
 if (tick === "c") {
for (let i = 0; i < meshes.length; i++) {
 let mesh = meshes[i];
 if (mesh.falling) {
for (let j = 0; j < grid.length; j++) {
 let cell = grid[j];
 let worldCell = toWorldView(cell);
 applyGravityToObject(mesh, worldCell);
}
 }
}
 }
 */
 
 
 updateCamera();
 profiler.draw();
profiler.reset();
 
 requestAnimationFrame(main);
}


window.onload=requestAnimationFrame(main);



