let MAX_VERTICES = 1_000_000; // ajustable según escena
let MAX_INDICES = 1_000_000;

let vertexBuffer = new Float32Array(MAX_VERTICES * 3);
let indexBuffer = new Uint16Array(MAX_INDICES);

let vertexOffset = 0;
let indexOffset = 0;

let cellMetadata = {}; // key: "col:row" → info
let meshKeys = []; // guarda keys en orden de generación

function pushVertex(x, y, z) {
 let index = vertexOffset / 3;
 vertexBuffer[vertexOffset++] = x;
 vertexBuffer[vertexOffset++] = y;
 vertexBuffer[vertexOffset++] = z;
 return index;
}

function generateCell(col, row, camPosX, camPosZ, subdivisions = 1) {
 let key = `${col + camPosX}:${row + camPosZ}`;
 
 let baseGridX = (col + camPosX) * cellSize;
 let baseGridZ = (row + camPosZ) * cellSize;
 
 let worldX = baseGridX * tileScale - offset;
 let worldZ = baseGridZ * tileScale - offset;
 
 let step = Math.max((cellSize / subdivisions) | 0, 1);
 
 let baseVertexIndex = vertexOffset / 3;
 let baseIndexIndex = indexOffset;
 
 for (let i = 0; i < cellSize; i += step) {
  for (let u = 0; u < cellSize; u += step) {
   let y00 = getY(u, i, col, row, camPosX, camPosZ);
   let y10 = getY(u + step, i, col, row, camPosX, camPosZ);
   let y01 = getY(u, i + step, col, row, camPosX, camPosZ);
   let y11 = getY(u + step, i + step, col, row, camPosX, camPosZ);
   
   let v0 = pushVertex(u, y00, i);
   let v1 = pushVertex(u + step, y10, i);
   let v2 = pushVertex(u + step, y11, i + step);
   let v3 = pushVertex(u, y01, i + step);
   
   // Triangle 1
   indexBuffer[indexOffset++] = v0;
   indexBuffer[indexOffset++] = v1;
   indexBuffer[indexOffset++] = v2;
   
   // Triangle 2
   indexBuffer[indexOffset++] = v0;
   indexBuffer[indexOffset++] = v2;
   indexBuffer[indexOffset++] = v3;
  }
 }
 
 cellMetadata[key] = {
  position: { x: worldX, y: 0, z: worldZ },
  rotation: { x: 0, y: 0, z: 0 },
  scale: tileScale,
  baseColor: { r: 50, g: 250, b: 50 },
  baseVertex: baseVertexIndex,
  vertexCount: (vertexOffset / 3) - baseVertexIndex,
  baseIndex: baseIndexIndex,
  indexCount: indexOffset - baseIndexIndex,
  subdivisions
 };
 
 meshKeys.push(key);
}

function createGrid(camPosX, camPosZ) {
 vertexOffset = 0;
 indexOffset = 0;
 cellMetadata = {};
 meshKeys = [];
 
 for (let row = 0; row < gridSize; row++) {
  for (let col = 0; col < gridSize; col++) {
   let posX = cellSize * (col + camPosX) * tileScale - offset;
   let posZ = cellSize * (row + camPosZ) * tileScale - offset;
   
   let dx = posX - camera.position.x;
   let dz = posZ - camera.position.z;
   let distance = Math.sqrt(dx * dx + dz * dz);
   
   if (gridLimit !== 0 &&
    (posX < -gridLimit || posX > gridLimit ||
     posZ < -gridLimit || posZ > gridLimit)) continue;
   
   let subdivisions = 1.1;
   if (distance > 600) subdivisions = 6;
   if (distance > 1200) subdivisions = 4;
   if (distance > 1800) subdivisions = 2;
   if (distance > 2500) subdivisions = 1;
   
   generateCell(col, row, camPosX, camPosZ, subdivisions);
  }
 }
 
 return meshKeys.map(key => cellMetadata[key]);
}

//-----------------------//

// local perlin
function getY(u, i, col, row, camPosX, camPosZ) {
 let worldX = (u + (col + camPosX) * cellSize) / tileScale;
 let worldZ = (i + (row + camPosZ) * cellSize) / tileScale;
 
 let scale = frequency || 0.1;
 let noiseVal = perlin(worldX * scale + random, worldZ * scale + random);
 
 let y = noiseVal * beef;
 return y;
}